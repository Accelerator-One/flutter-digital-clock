# Digital Clock
Digital clock developed using flutter.<br>
It has a light/dark theme and also displays
 weather and temperature of the specified region.

<img src='digital_dark.png' width='350'>

<img src='digital_light.png' width='350'>
