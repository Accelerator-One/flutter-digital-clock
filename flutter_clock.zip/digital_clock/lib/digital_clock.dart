import 'dart:async';
import 'package:flutter_clock_helper/model.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

enum _Element { background, text }

final _lightTheme = {
  _Element.background: Colors.white70,
  _Element.text: Colors.grey[900],
};

final _darkTheme = {
  _Element.background: Colors.grey[900],
  _Element.text: Colors.white,
};

/// A basic digital clock.
class DigitalClock extends StatefulWidget {
  const DigitalClock(this.model);
  final ClockModel model;

  @override
  _DigitalClockState createState() => _DigitalClockState();
}

class _DigitalClockState extends State<DigitalClock> {
  DateTime _dateTime = DateTime.now();
  Timer _timer;
  var _temperature;
  var _condition;
  Icon _weather;

  @override
  void initState() {
    super.initState();
    widget.model.addListener(_updateModel);
    _updateTime();
    _updateModel();
  }

  @override
  void didUpdateWidget(DigitalClock oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.model != oldWidget.model) {
      oldWidget.model.removeListener(_updateModel);
      widget.model.addListener(_updateModel);
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    widget.model.removeListener(_updateModel);
    widget.model.dispose();
    super.dispose();
  }

  String _miniTemp(String s) {
    int i = s.length - 1;
    int j;
    // Removing Precision for Space
    for (j = 0; j < i; j++) if (s[j] == '.') break;

    String mini = s.substring(0, j) + s[i - 1];
    return mini;
  }

  void _updateModel() {
    setState(() {
      // Rebuild Clock when the model changes
      _temperature = _miniTemp(widget.model.temperatureString);
      _condition = widget.model.weatherString;

      // Adding Icons as per the Use-Cases
      if (_condition == 'sunny')
        _weather = Icon(Icons.wb_sunny);
      else if (_condition == 'cloudy')
        _weather = Icon(Icons.cloud);
      else if (_condition == 'snow')
        _weather = Icon(Icons.ac_unit);
      else
        _weather = Icon(Icons.adjust);
    });
  }

  void _updateTime() {
    setState(() {
      _dateTime = DateTime.now();
      _timer = Timer(Duration(seconds: 1), _updateTime);
    });
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).brightness == Brightness.light
        ? _lightTheme
        : _darkTheme;
    final hour =
        DateFormat(widget.model.is24HourFormat ? 'HH' : 'hh').format(_dateTime);
    final minute = DateFormat('mm').format(_dateTime);
    final fontSize = MediaQuery.of(context).size.width / 3.5;
    final _defaultStyle = TextStyle(
      color: colors[_Element.text],
      fontFamily: 'OpenSans',
      fontSize: fontSize,
    );

    // Used Variables : hour, minute
    return Container(
      color: colors[_Element.background],
      child: Row(
        children: <Widget>[
          Expanded(
            flex: 1,
            child: SizedBox(
              height: 4,
            ),
          ),
          Expanded(
              flex: 4, child: Center(child: Text(hour, style: _defaultStyle))),
          Expanded(
              flex: 2,
              child: Column(
                children: <Widget>[
                  Expanded(
                    flex: 3,
                    child: SizedBox(
                      width: 4,
                    ),
                  ),
                  Expanded(
                      child: Text(
                        _temperature,
                        style: TextStyle(
                            letterSpacing: 0.6,
                            fontWeight: FontWeight.w800,
                            fontSize: 16),
                      ),
                      flex: 2),
                  Expanded(child: Center(child: _weather), flex: 2),
                  Expanded(
                      child: SizedBox(
                        width: 4,
                      ),
                      flex: 2)
                ],
              )),
          Expanded(
              flex: 4,
              child: Center(
                  child: Container(child: Text(minute, style: _defaultStyle)))),
          Expanded(flex: 1, child: SizedBox(height: 4))
        ],
      ),
    );
  }
}
